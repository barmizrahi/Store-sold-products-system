package Model;

public interface Command {
	void execute();
}
