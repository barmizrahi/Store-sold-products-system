package Model;



public interface Observer {
	void update(Observable o, Update arg);
}
