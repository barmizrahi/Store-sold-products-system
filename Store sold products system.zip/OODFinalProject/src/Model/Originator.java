package Model;

public interface Originator {
	MementoClass saveMemento();
}
