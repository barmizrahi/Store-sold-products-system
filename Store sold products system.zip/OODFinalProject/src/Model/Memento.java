package Model;

public interface Memento {
		ProductMemento restoreMemento();
}
